"""Claude API 调参引擎：分析阶跃响应数据，给出新 PID 参数建议"""

import json

import anthropic

import config
from protocol import Telemetry

SYSTEM_PROMPT = """\
你是一个嵌入式系统 PID 调参专家。你的任务是根据阶跃响应数据分析系统表现，并给出改进的 PID 参数。

规则：
1. 分析超调量、上升时间、稳态误差、振荡情况
2. 基于分析结果调整 Kp、Ki、Kd
3. 每次调整幅度要适中，避免剧烈变化导致系统不稳定
4. 必须严格按 JSON 格式输出，不要输出其他内容

输出格式（严格JSON，无其他文字）：
{"kp": <float>, "ki": <float>, "kd": <float>, "reasoning": "<简短分析>"}
"""


def compute_metrics(
    telemetry: list[Telemetry], setpoint: float
) -> dict:
    """从遥测数据中计算阶跃响应性能指标"""
    if not telemetry:
        return {}

    actuals = [t.actual for t in telemetry]
    times_sec = [t.tick_ms / 1000.0 for t in telemetry]
    final_value = actuals[-1]

    # 超调量
    peak = max(actuals)
    if setpoint != 0:
        overshoot_pct = max(0, (peak - setpoint) / abs(setpoint) * 100)
    else:
        overshoot_pct = 0.0

    # 上升时间 (10% → 90%)
    rise_start = setpoint * 0.1
    rise_end = setpoint * 0.9
    rise_time = None
    t_start = None
    for i, val in enumerate(actuals):
        if t_start is None and val >= rise_start:
            t_start = times_sec[i]
        if t_start is not None and val >= rise_end:
            rise_time = times_sec[i] - t_start
            break

    # 稳态误差 (取最后 20% 数据的平均)
    tail_start = int(len(actuals) * 0.8)
    tail = actuals[tail_start:]
    steady_state = sum(tail) / len(tail) if tail else final_value
    if setpoint != 0:
        steady_error_pct = abs(setpoint - steady_state) / abs(setpoint) * 100
    else:
        steady_error_pct = abs(steady_state)

    # 振荡次数 (过零点计数)
    errors = [t.error for t in telemetry]
    oscillations = 0
    for i in range(1, len(errors)):
        if errors[i - 1] * errors[i] < 0:
            oscillations += 1
    oscillations = oscillations // 2  # 一个完整振荡 = 2次过零

    # 调节时间 (误差持续 < 5% 设定值的时刻)
    settle_time = None
    if setpoint != 0:
        threshold = abs(setpoint) * 0.05
        for i in range(len(actuals) - 1, -1, -1):
            if abs(actuals[i] - setpoint) > threshold:
                if i + 1 < len(times_sec):
                    settle_time = times_sec[i + 1]
                break

    return {
        "overshoot_pct": round(overshoot_pct, 2),
        "rise_time_sec": round(rise_time, 4) if rise_time else None,
        "steady_error_pct": round(steady_error_pct, 2),
        "oscillations": oscillations,
        "settle_time_sec": round(settle_time, 4) if settle_time else None,
        "peak_value": round(peak, 2),
        "final_value": round(final_value, 2),
    }


def ask_claude(
    kp: float,
    ki: float,
    kd: float,
    metrics: dict,
    error_curve: list[float],
) -> dict:
    """调用 Claude API，返回建议的新 PID 参数

    Returns:
        {"kp": float, "ki": float, "kd": float, "reasoning": str}
    Raises:
        ValueError: Claude 返回了无法解析的内容
    """
    # 下采样误差曲线，最多发 50 个点
    if len(error_curve) > 50:
        step = len(error_curve) // 50
        error_curve = error_curve[::step]

    user_msg = (
        f"当前 PID 参数: Kp={kp}, Ki={ki}, Kd={kd}\n"
        f"阶跃响应性能指标:\n{json.dumps(metrics, indent=2, ensure_ascii=False)}\n"
        f"误差曲线 (等间隔采样, 共{len(error_curve)}点): {[round(e, 2) for e in error_curve]}\n"
        f"\n"
        f"参数允许范围: Kp∈{list(config.PID_BOUNDS['kp'])}, "
        f"Ki∈{list(config.PID_BOUNDS['ki'])}, Kd∈{list(config.PID_BOUNDS['kd'])}\n"
        f"请给出改进后的参数。"
    )

    client = anthropic.Anthropic()
    response = client.messages.create(
        model=config.CLAUDE_MODEL,
        max_tokens=config.CLAUDE_MAX_TOKENS,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_msg}],
    )

    text = response.content[0].text.strip()

    # 尝试提取 JSON（Claude 可能在 JSON 前后加文字）
    start = text.find("{")
    end = text.rfind("}") + 1
    if start == -1 or end == 0:
        raise ValueError(f"Claude 返回内容中未找到 JSON: {text}")

    result = json.loads(text[start:end])

    # 校验必要字段
    for key in ("kp", "ki", "kd"):
        if key not in result:
            raise ValueError(f"Claude 返回的 JSON 中缺少 '{key}': {result}")
        result[key] = float(result[key])

    result.setdefault("reasoning", "")
    return result
