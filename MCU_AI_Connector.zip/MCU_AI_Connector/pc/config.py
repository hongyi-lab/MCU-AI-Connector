"""配置文件：所有可调参数集中管理"""

# ── 串口配置 ──
SERIAL_PORT = "COM3"        # Windows: "COM3", Linux: "/dev/ttyUSB0"
SERIAL_BAUDRATE = 115200
SERIAL_TIMEOUT = 0.1        # 读超时(秒)

# ── PID 参数安全边界 ──
PID_BOUNDS = {
    "kp": (0.05, 20.0),
    "ki": (0.0, 5.0),
    "kd": (0.0, 10.0),
}

# 每次调参，单个参数最大变化比例 (50% = 参数最多变为原来的 0.5x ~ 1.5x)
MAX_CHANGE_RATIO = 0.5

# ── 初始 PID 参数 ──
INITIAL_KP = 1.0
INITIAL_KI = 0.01
INITIAL_KD = 0.1

# ── 调参流程配置 ──
STEP_TARGET = 100.0         # 阶跃目标值
DATA_COLLECTION_SEC = 3.0   # 每轮采集数据时长(秒)
SETTLE_SEC = 1.0            # 写入新参数后等待稳定时间(秒)
MAX_ITERATIONS = 20         # 最大自动调参轮数
TELEMETRY_INTERVAL_MS = 10  # MCU 遥测上报间隔(毫秒)，用于 FakeSerial

# ── 收敛判定 ──
TARGET_OVERSHOOT = 5.0      # 目标超调量 (%)
TARGET_SETTLE_TIME = 1.0    # 目标调节时间 (秒)
TARGET_STEADY_ERROR = 1.0   # 目标稳态误差 (%)

# ── Claude API 配置 ──
CLAUDE_MODEL = "claude-sonnet-4-6"
CLAUDE_MAX_TOKENS = 512

# ── 日志 ──
LOG_FILE = "tuning_log.json"
