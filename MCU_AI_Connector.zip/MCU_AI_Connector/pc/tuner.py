"""调参主循环：编排采集 → 分析 → Claude → 安全检查 → 下发的完整流程"""

import time
import json
from pathlib import Path

import config
from protocol import Telemetry, decode_line, encode_pid, encode_step
from analyzer import compute_metrics, ask_claude
from safety import clamp_params, check_divergence


class PIDTuner:
    def __init__(self, conn):
        """
        Args:
            conn: SerialConnection 或 FakeSerial 实例，需要有
                  open/close/send/readline 方法
        """
        self.conn = conn
        self.kp = config.INITIAL_KP
        self.ki = config.INITIAL_KI
        self.kd = config.INITIAL_KD
        self.history: list[dict] = []  # 每轮调参记录

    def collect_step_response(self) -> list[Telemetry]:
        """发送阶跃信号并采集一段完整的响应数据"""
        # 先下发当前 PID 参数
        self.conn.send(encode_pid(self.kp, self.ki, self.kd))
        time.sleep(0.1)

        # 发送阶跃命令
        self.conn.send(encode_step(config.STEP_TARGET))

        # 采集数据
        telemetry = []
        start = time.time()
        while time.time() - start < config.DATA_COLLECTION_SEC:
            line = self.conn.readline()
            if line is None:
                continue
            parsed = decode_line(line)
            if parsed and parsed["type"] == "telemetry":
                telemetry.append(parsed["data"])

        return telemetry

    def run_one_iteration(self, iteration: int) -> dict:
        """执行一轮调参，返回本轮记录"""
        print(f"\n{'='*60}")
        print(f"  第 {iteration + 1} 轮调参")
        print(f"  当前参数: Kp={self.kp:.4f}, Ki={self.ki:.4f}, Kd={self.kd:.4f}")
        print(f"{'='*60}")

        # 1. 采集阶跃响应
        print("  [1/4] 采集阶跃响应数据...")
        telemetry = self.collect_step_response()
        print(f"        收到 {len(telemetry)} 个数据点")

        if len(telemetry) < 5:
            print("        数据不足，跳过本轮")
            return {"iteration": iteration, "status": "insufficient_data"}

        # 2. 计算性能指标
        metrics = compute_metrics(telemetry, config.STEP_TARGET)
        print(f"  [2/4] 性能指标:")
        print(f"        超调: {metrics.get('overshoot_pct', '?')}%")
        print(f"        上升时间: {metrics.get('rise_time_sec', '?')}s")
        print(f"        稳态误差: {metrics.get('steady_error_pct', '?')}%")
        print(f"        振荡次数: {metrics.get('oscillations', '?')}")

        # 检测发散
        if check_divergence(telemetry):
            print("  !! 检测到系统发散，回退到上一组参数 !!")
            if self.history:
                last = self.history[-1]
                self.kp = last["params"]["kp"]
                self.ki = last["params"]["ki"]
                self.kd = last["params"]["kd"]
            return {"iteration": iteration, "status": "diverged", "metrics": metrics}

        # 3. 调用 Claude
        print("  [3/4] 调用 Claude 分析...")
        error_curve = [t.error for t in telemetry]
        try:
            suggestion = ask_claude(
                self.kp, self.ki, self.kd, metrics, error_curve
            )
        except Exception as e:
            print(f"        Claude 调用失败: {e}")
            return {"iteration": iteration, "status": "claude_error", "error": str(e)}

        print(f"        Claude 建议: Kp={suggestion['kp']:.4f}, "
              f"Ki={suggestion['ki']:.4f}, Kd={suggestion['kd']:.4f}")
        print(f"        分析: {suggestion.get('reasoning', '')}")

        # 4. 安全检查
        new_kp, new_ki, new_kd, warnings = clamp_params(
            suggestion["kp"], suggestion["ki"], suggestion["kd"],
            self.kp, self.ki, self.kd,
        )
        if warnings:
            print("  [4/4] 安全裁剪:")
            for w in warnings:
                print(f"        {w}")
        else:
            print("  [4/4] 参数在安全范围内")

        # 记录
        record = {
            "iteration": iteration,
            "status": "ok",
            "old_params": {"kp": self.kp, "ki": self.ki, "kd": self.kd},
            "metrics": metrics,
            "claude_suggestion": {
                "kp": suggestion["kp"],
                "ki": suggestion["ki"],
                "kd": suggestion["kd"],
                "reasoning": suggestion.get("reasoning", ""),
            },
            "applied_params": {"kp": new_kp, "ki": new_ki, "kd": new_kd},
            "safety_warnings": warnings,
        }
        self.history.append(record)

        # 更新参数
        self.kp, self.ki, self.kd = new_kp, new_ki, new_kd
        print(f"\n  应用参数: Kp={self.kp:.4f}, Ki={self.ki:.4f}, Kd={self.kd:.4f}")

        return record

    def check_converged(self, metrics: dict) -> bool:
        """检查是否达到调参目标"""
        overshoot = metrics.get("overshoot_pct", 999)
        settle = metrics.get("settle_time_sec")
        steady_err = metrics.get("steady_error_pct", 999)

        ok = (
            overshoot <= config.TARGET_OVERSHOOT
            and (settle is not None and settle <= config.TARGET_SETTLE_TIME)
            and steady_err <= config.TARGET_STEADY_ERROR
        )
        return ok

    def run(self):
        """运行完整的自动调参流程"""
        print("=" * 60)
        print("  PID 自动调参工具 (Claude AI)")
        print("=" * 60)

        self.conn.open()

        try:
            for i in range(config.MAX_ITERATIONS):
                record = self.run_one_iteration(i)

                # 检查收敛
                if record.get("status") == "ok":
                    if self.check_converged(record["metrics"]):
                        print("\n  *** 调参收敛！达到目标性能指标 ***")
                        break

                # 等待系统稳定
                print(f"\n  等待 {config.SETTLE_SEC}s 让系统稳定...")
                time.sleep(config.SETTLE_SEC)
            else:
                print(f"\n  达到最大迭代次数 ({config.MAX_ITERATIONS})，自动停止")

            # 最终结果
            print(f"\n{'='*60}")
            print(f"  最终参数: Kp={self.kp:.4f}, Ki={self.ki:.4f}, Kd={self.kd:.4f}")
            print(f"  共执行 {len(self.history)} 轮调参")
            print(f"{'='*60}")

        finally:
            self.conn.close()
            self._save_log()

    def _save_log(self):
        """保存调参日志到 JSON 文件"""
        log_path = Path(config.LOG_FILE)
        log_data = {
            "final_params": {"kp": self.kp, "ki": self.ki, "kd": self.kd},
            "iterations": self.history,
        }
        log_path.write_text(json.dumps(log_data, indent=2, ensure_ascii=False))
        print(f"\n  调参日志已保存到: {log_path.absolute()}")
