"""串口连接层：真实串口 + FakeSerial 模拟器"""

import time
import threading
import queue
from collections import deque

import serial

from protocol import Telemetry, decode_line, encode_pid, encode_step, encode_query
import config


class SerialConnection:
    """真实串口连接"""

    def __init__(self, port=None, baudrate=None):
        self.port = port or config.SERIAL_PORT
        self.baudrate = baudrate or config.SERIAL_BAUDRATE
        self.ser = None

    def open(self):
        self.ser = serial.Serial(
            self.port, self.baudrate, timeout=config.SERIAL_TIMEOUT
        )
        time.sleep(2)  # 等 MCU 复位

    def close(self):
        if self.ser and self.ser.is_open:
            self.ser.close()

    def send(self, data: bytes):
        self.ser.write(data)

    def readline(self) -> str | None:
        raw = self.ser.readline()
        if raw:
            return raw.decode(errors="ignore").strip()
        return None


class FakeSerial:
    """模拟一个带 PID 控制的一阶惯性系统

    传递函数: G(s) = K / (Ts + 1)
    用欧拉法离散化，内置 PID 控制器。
    收到 $STEP 后开始仿真并输出遥测数据。
    """

    def __init__(self):
        # 被控对象参数
        self.plant_K = 1.0      # 系统增益
        self.plant_T = 0.3      # 时间常数(秒)
        self.dt = config.TELEMETRY_INTERVAL_MS / 1000.0

        # PID 参数
        self.kp = config.INITIAL_KP
        self.ki = config.INITIAL_KI
        self.kd = config.INITIAL_KD

        # 状态
        self.setpoint = 0.0
        self.actual = 0.0
        self.integral = 0.0
        self.prev_error = 0.0
        self.tick_ms = 0
        self.running = False

        # 输出队列（模拟 MCU 发来的数据）
        self._output_queue: queue.Queue[str] = queue.Queue()
        self._sim_thread: threading.Thread | None = None

    def open(self):
        pass

    def close(self):
        self.running = False
        if self._sim_thread and self._sim_thread.is_alive():
            self._sim_thread.join(timeout=2)

    def send(self, data: bytes):
        line = data.decode().strip()
        parts = line.split(",")
        cmd = parts[0]

        if cmd == "$PID" and len(parts) == 4:
            self.kp = float(parts[1])
            self.ki = float(parts[2])
            self.kd = float(parts[3])
            # 重置积分项，避免积分饱和带到新参数
            self.integral = 0.0
            self.prev_error = 0.0
        elif cmd == "$STEP" and len(parts) == 2:
            self.setpoint = float(parts[1])
            self._start_sim()
        elif cmd == "$QUERY":
            self._output_queue.put(
                f"$PARAM,{self.kp:.6f},{self.ki:.6f},{self.kd:.6f}"
            )

    def readline(self) -> str | None:
        try:
            return self._output_queue.get(timeout=config.SERIAL_TIMEOUT)
        except queue.Empty:
            return None

    def _start_sim(self):
        """启动仿真线程"""
        self.running = False
        if self._sim_thread and self._sim_thread.is_alive():
            self._sim_thread.join(timeout=2)

        # 重置状态
        self.actual = 0.0
        self.integral = 0.0
        self.prev_error = 0.0
        self.tick_ms = 0
        self.running = True

        self._sim_thread = threading.Thread(target=self._sim_loop, daemon=True)
        self._sim_thread.start()

    def _sim_loop(self):
        """仿真主循环：PID 控制 + 一阶惯性系统"""
        while self.running:
            error = self.setpoint - self.actual

            # PID
            self.integral += error * self.dt
            # 积分限幅
            self.integral = max(-500, min(500, self.integral))
            derivative = (error - self.prev_error) / self.dt if self.dt > 0 else 0
            pwm = self.kp * error + self.ki * self.integral + self.kd * derivative
            pwm = max(-1000, min(1000, pwm))  # PWM 限幅
            self.prev_error = error

            # 一阶惯性系统响应: T * dy/dt + y = K * u
            # 欧拉法: y[n+1] = y[n] + dt/T * (K*u - y[n])
            self.actual += (self.dt / self.plant_T) * (
                self.plant_K * pwm - self.actual
            )

            # 输出遥测
            tel = (
                f"$TEL,{self.tick_ms},{self.setpoint:.2f},"
                f"{self.actual:.2f},{error:.2f},{pwm:.2f}"
            )
            self._output_queue.put(tel)

            self.tick_ms += config.TELEMETRY_INTERVAL_MS
            time.sleep(self.dt)
