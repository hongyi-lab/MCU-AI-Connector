"""PID 参数安全检查：边界裁剪、变化幅度限制、发散检测"""

import config
from protocol import Telemetry


def clamp_params(
    new_kp: float,
    new_ki: float,
    new_kd: float,
    old_kp: float,
    old_ki: float,
    old_kd: float,
) -> tuple[float, float, float, list[str]]:
    """对新参数进行安全裁剪

    1. 限制在绝对范围内
    2. 限制单次变化幅度（相对于旧值 ±MAX_CHANGE_RATIO）

    Returns:
        (kp, ki, kd, warnings) — warnings 列表记录被裁剪的项
    """
    warnings = []
    ratio = config.MAX_CHANGE_RATIO

    def _clamp_one(name, new_val, old_val, bounds):
        lo, hi = bounds
        w = []

        # 变化幅度限制
        if old_val > 0:
            min_val = old_val * (1 - ratio)
            max_val = old_val * (1 + ratio)
            if new_val < min_val:
                w.append(f"{name}: {new_val:.4f} → {min_val:.4f} (变化过大，裁剪到-{ratio*100:.0f}%)")
                new_val = min_val
            elif new_val > max_val:
                w.append(f"{name}: {new_val:.4f} → {max_val:.4f} (变化过大，裁剪到+{ratio*100:.0f}%)")
                new_val = max_val

        # 绝对范围限制
        if new_val < lo:
            w.append(f"{name}: {new_val:.4f} → {lo} (低于下限)")
            new_val = lo
        elif new_val > hi:
            w.append(f"{name}: {new_val:.4f} → {hi} (超过上限)")
            new_val = hi

        return new_val, w

    kp, w = _clamp_one("Kp", new_kp, old_kp, config.PID_BOUNDS["kp"])
    warnings.extend(w)
    ki, w = _clamp_one("Ki", new_ki, old_ki, config.PID_BOUNDS["ki"])
    warnings.extend(w)
    kd, w = _clamp_one("Kd", new_kd, old_kd, config.PID_BOUNDS["kd"])
    warnings.extend(w)

    return kp, ki, kd, warnings


def check_divergence(telemetry: list[Telemetry], threshold: float = 3.0) -> bool:
    """检测系统是否发散

    如果误差在后半段持续增大且超过设定值的 threshold 倍，判定为发散。
    """
    if len(telemetry) < 10:
        return False

    setpoint = telemetry[0].setpoint
    if setpoint == 0:
        return False

    # 看后半段误差是否持续增大
    half = len(telemetry) // 2
    later_errors = [abs(t.error) for t in telemetry[half:]]
    max_error = max(later_errors)

    return max_error > abs(setpoint) * threshold
