"""UART 文本协议编解码

帧格式 (ASCII, 以 \n 结尾):
  遥测上报:  $TEL,<tick_ms>,<setpoint>,<actual>,<error>,<pwm>\n
  设置PID:   $PID,<kp>,<ki>,<kd>\n
  阶跃命令:  $STEP,<target>\n
  查询参数:  $QUERY\n
  查询回复:  $PARAM,<kp>,<ki>,<kd>\n
"""

from dataclasses import dataclass


@dataclass
class Telemetry:
    tick_ms: int
    setpoint: float
    actual: float
    error: float
    pwm: float


def encode_pid(kp: float, ki: float, kd: float) -> bytes:
    return f"$PID,{kp:.6f},{ki:.6f},{kd:.6f}\n".encode()


def encode_step(target: float) -> bytes:
    return f"$STEP,{target:.2f}\n".encode()


def encode_query() -> bytes:
    return b"$QUERY\n"


def decode_line(line: str) -> dict | None:
    """解析一行 MCU 上报的数据，返回 dict 或 None（无法解析时）"""
    line = line.strip()
    if not line.startswith("$"):
        return None

    parts = line.split(",")
    cmd = parts[0]

    try:
        if cmd == "$TEL" and len(parts) == 6:
            return {
                "type": "telemetry",
                "data": Telemetry(
                    tick_ms=int(parts[1]),
                    setpoint=float(parts[2]),
                    actual=float(parts[3]),
                    error=float(parts[4]),
                    pwm=float(parts[5]),
                ),
            }
        elif cmd == "$PARAM" and len(parts) == 4:
            return {
                "type": "param",
                "kp": float(parts[1]),
                "ki": float(parts[2]),
                "kd": float(parts[3]),
            }
    except (ValueError, IndexError):
        return None

    return None
