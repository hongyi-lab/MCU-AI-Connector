"""入口：PID 自动调参工具

用法:
    # 模拟模式（无需硬件）
    python main.py --simulate

    # 真实串口
    python main.py --port COM3

    # 指定波特率
    python main.py --port /dev/ttyUSB0 --baud 115200
"""

import argparse
import sys

import config
from serial_conn import SerialConnection, FakeSerial
from tuner import PIDTuner


def main():
    parser = argparse.ArgumentParser(description="PID 自动调参工具 (Claude AI)")
    parser.add_argument(
        "--simulate", action="store_true",
        help="使用 FakeSerial 模拟器，无需真实硬件",
    )
    parser.add_argument("--port", type=str, help="串口号，如 COM3 或 /dev/ttyUSB0")
    parser.add_argument("--baud", type=int, help="波特率")
    parser.add_argument("--kp", type=float, help="初始 Kp")
    parser.add_argument("--ki", type=float, help="初始 Ki")
    parser.add_argument("--kd", type=float, help="初始 Kd")
    parser.add_argument("--max-iter", type=int, help="最大迭代次数")

    args = parser.parse_args()

    # 覆盖配置
    if args.max_iter:
        config.MAX_ITERATIONS = args.max_iter

    # 创建连接
    if args.simulate:
        print("使用 FakeSerial 模拟器")
        conn = FakeSerial()
    elif args.port:
        conn = SerialConnection(port=args.port, baudrate=args.baud)
    else:
        print("错误: 请指定 --simulate 或 --port")
        print("示例:")
        print("  python main.py --simulate")
        print("  python main.py --port COM3")
        sys.exit(1)

    # 创建调参器
    tuner = PIDTuner(conn)
    if args.kp is not None:
        tuner.kp = args.kp
    if args.ki is not None:
        tuner.ki = args.ki
    if args.kd is not None:
        tuner.kd = args.kd

    # 运行
    tuner.run()


if __name__ == "__main__":
    main()
