# MCU_AI_Connector

用 Claude AI 自动调 PID 参数的工具包。通过 UART 串口连接 STM32，采集阶跃响应数据，让 AI 分析并迭代优化 Kp/Ki/Kd，直到系统收敛。

```
PC (Python)                    UART                    MCU (STM32)
┌──────────────────┐   $PID/$STEP ──────────►   ┌─────────────────┐
│  tuner.py        │                             │  PID 控制器      │
│  ┌────────────┐  │   ◄────────── $TEL 遥测     │  被控对象        │
│  │ Claude API │  │                             └─────────────────┘
│  └────────────┘  │
└──────────────────┘
```

## 目录结构

```
MCU_AI_Connector/
├── pc/
│   ├── main.py          # CLI 入口
│   ├── config.py        # 所有配置项
│   ├── tuner.py         # 主循环编排
│   ├── analyzer.py      # 性能指标计算 + Claude API 调用
│   ├── safety.py        # 参数裁剪与发散检测
│   ├── serial_conn.py   # 真实串口 + FakeSerial 仿真器
│   ├── protocol.py      # UART 协议编解码
│   └── tuning_log.json  # 调参日志（运行后自动生成）
└── mcu/
    ├── pid_uart_bridge.c  # STM32 端实现
    └── pid_uart_bridge.h  # STM32 端头文件
```

## 快速开始

### 1. 安装依赖

```bash
pip install anthropic pyserial
```

### 2. 设置 API Key

```bash
# Windows
set ANTHROPIC_API_KEY=sk-ant-...

# Linux / macOS
export ANTHROPIC_API_KEY=sk-ant-...
```

### 3. 运行

```bash
cd pc

# 纯软件仿真，无需硬件
python main.py --simulate

# 连接真实 MCU
python main.py --port COM3

# 指定初始参数和最大迭代次数
python main.py --simulate --kp 2.0 --ki 0.05 --kd 0.5 --max-iter 10
```

## 调参流程

每轮迭代执行以下 4 步：

```
[1/4] 发 $STEP 命令，采集 3 秒遥测数据
[2/4] 计算超调量、上升时间、稳态误差、振荡次数
[3/4] 将指标发给 Claude，获取新 Kp/Ki/Kd 建议
[4/4] 安全裁剪（限幅 + 发散检测），下发新参数
```

满足以下三项时自动停止：

| 指标 | 默认目标 |
|------|----------|
| 超调量 | ≤ 5% |
| 调节时间 | ≤ 1.0 s |
| 稳态误差 | ≤ 1% |

## 主要配置（`pc/config.py`）

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| `SERIAL_PORT` | `"COM3"` | 串口号 |
| `SERIAL_BAUDRATE` | `115200` | 波特率 |
| `INITIAL_KP/KI/KD` | `1.0 / 0.01 / 0.1` | 初始 PID 参数 |
| `PID_BOUNDS` | Kp∈[0.05,20] Ki∈[0,5] Kd∈[0,10] | 参数安全边界 |
| `MAX_CHANGE_RATIO` | `0.5` | 单次调整最大幅度（±50%） |
| `STEP_TARGET` | `100.0` | 阶跃目标值 |
| `DATA_COLLECTION_SEC` | `3.0` | 每轮采集时长（秒） |
| `MAX_ITERATIONS` | `20` | 最大迭代轮数 |

## MCU 端接入（STM32 + Keil）

将 `mcu/pid_uart_bridge.c` 和 `pid_uart_bridge.h` 复制到 Keil 工程，然后：

**`main.c` — 初始化**

```c
#include "pid_uart_bridge.h"

// HAL_Init() 之后调用
PID_Bridge_Init(&huart1);  // 换成你使用的 UART 句柄
```

**中断回调 — 逐字节转发给解析器**

```c
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    PID_Bridge_RxCallback(rx_byte);
    HAL_UART_Receive_IT(huart, &rx_byte, 1);  // 重新挂起接收
}
```

**PID 控制循环 — 读参数 / 上报遥测**

```c
// 读取 PC 下发的最新 PID 参数
PID_Params_t p = PID_Bridge_GetParams();

// 检查是否有新的阶跃命令
uint8_t has_new;
float target = PID_Bridge_GetStepTarget(&has_new);
if (has_new) setpoint = target;

// ... 你的 PID 计算 ...

// 上报遥测
PID_Bridge_SendTelemetry(HAL_GetTick(), setpoint, actual, error, output);
```

**CubeMX 配置要求**
- UART：115200 波特率，8N1，开启中断接收
- 根据芯片型号修改 `pid_uart_bridge.h` 第 19 行的 HAL 头文件（默认 `stm32f1xx_hal.h`）

## UART 协议

所有帧为 ASCII 文本，以 `\n` 结尾。

| 方向 | 帧格式 | 说明 |
|------|--------|------|
| PC → MCU | `$PID,<kp>,<ki>,<kd>` | 设置 PID 参数 |
| PC → MCU | `$STEP,<target>` | 发送阶跃命令 |
| PC → MCU | `$QUERY` | 查询当前参数 |
| MCU → PC | `$TEL,<tick_ms>,<setpoint>,<actual>,<error>,<pwm>` | 遥测上报 |
| MCU → PC | `$PARAM,<kp>,<ki>,<kd>` | 参数查询回复 |

## 安全机制

- **单次变化限幅**：每轮参数调整幅度不超过当前值的 ±50%（`MAX_CHANGE_RATIO`）
- **绝对边界裁剪**：参数始终限制在 `PID_BOUNDS` 范围内
- **发散检测**：若后半段误差持续超过设定值的 3 倍，自动回退到上一组参数

## 调参日志

每次运行结束后，完整历史记录保存到 `pc/tuning_log.json`：

```json
{
  "final_params": {"kp": 0.95, "ki": 0.012, "kd": 0.21},
  "iterations": [
    {
      "iteration": 0,
      "status": "ok",
      "old_params": {"kp": 1.0, "ki": 0.01, "kd": 0.1},
      "metrics": {"overshoot_pct": 23.5, "rise_time_sec": 0.42, ...},
      "claude_suggestion": {"kp": 0.8, "ki": 0.012, "kd": 0.18, "reasoning": "..."},
      "applied_params": {"kp": 0.8, "ki": 0.012, "kd": 0.18},
      "safety_warnings": []
    }
  ]
}
```
