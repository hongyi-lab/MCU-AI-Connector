/**
 * PID UART Bridge — 在 Keil STM32 项目中加入这两个文件
 *
 * 功能：
 *   1. 通过 UART 接收 PC 端的 PID 参数和阶跃命令
 *   2. 在控制循环中通过 UART 上报遥测数据
 *
 * 使用方法：
 *   1. 在 main.c 中 #include "pid_uart_bridge.h"
 *   2. 初始化时调用 PID_Bridge_Init(&huart1)  // 你用的 UART 句柄
 *   3. 在 UART 接收中断回调里调用 PID_Bridge_RxCallback(byte)
 *   4. 在 PID 控制循环里调用 PID_Bridge_SendTelemetry(...)
 *   5. 用 PID_Bridge_GetParams() 获取最新的 PID 参数
 */

#ifndef PID_UART_BRIDGE_H
#define PID_UART_BRIDGE_H

#include "stm32f1xx_hal.h"  // 根据你的芯片改，如 stm32f4xx_hal.h
#include <stdint.h>

typedef struct {
    float kp;
    float ki;
    float kd;
} PID_Params_t;

/* 初始化，传入 UART 句柄 */
void PID_Bridge_Init(UART_HandleTypeDef *huart);

/* 在 UART 接收中断里逐字节调用 */
void PID_Bridge_RxCallback(uint8_t byte);

/* 在 PID 控制循环中调用，上报遥测数据 */
void PID_Bridge_SendTelemetry(uint32_t tick_ms, float setpoint,
                               float actual, float error, float pwm);

/* 获取当前 PID 参数（由 PC 端设置） */
PID_Params_t PID_Bridge_GetParams(void);

/* 获取阶跃目标值，返回 0 表示未收到新命令 */
float PID_Bridge_GetStepTarget(uint8_t *has_new);

#endif /* PID_UART_BRIDGE_H */
