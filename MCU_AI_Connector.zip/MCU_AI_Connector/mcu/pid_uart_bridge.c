/**
 * PID UART Bridge 实现
 *
 * 协议 (ASCII, \n 结尾):
 *   PC → MCU:
 *     $PID,<kp>,<ki>,<kd>\n       设置PID参数
 *     $STEP,<target>\n             设置阶跃目标
 *     $QUERY\n                     查询当前参数
 *
 *   MCU → PC:
 *     $TEL,<tick>,<sp>,<act>,<err>,<pwm>\n   遥测上报
 *     $PARAM,<kp>,<ki>,<kd>\n                 参数回复
 */

#include "pid_uart_bridge.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- 内部状态 ---- */
static UART_HandleTypeDef *s_huart;
static PID_Params_t s_params = {1.0f, 0.01f, 0.1f};
static float s_step_target = 0.0f;
static uint8_t s_has_new_step = 0;

/* 接收缓冲 */
#define RX_BUF_SIZE 128
static char s_rx_buf[RX_BUF_SIZE];
static uint16_t s_rx_idx = 0;

/* 发送缓冲 */
static char s_tx_buf[128];

/* ---- 内部函数 ---- */
static void process_command(const char *line);

void PID_Bridge_Init(UART_HandleTypeDef *huart) {
    s_huart = huart;
    s_rx_idx = 0;
}

void PID_Bridge_RxCallback(uint8_t byte) {
    if (byte == '\n' || byte == '\r') {
        if (s_rx_idx > 0) {
            s_rx_buf[s_rx_idx] = '\0';
            process_command(s_rx_buf);
            s_rx_idx = 0;
        }
    } else {
        if (s_rx_idx < RX_BUF_SIZE - 1) {
            s_rx_buf[s_rx_idx++] = (char)byte;
        } else {
            /* 溢出，丢弃 */
            s_rx_idx = 0;
        }
    }
}

void PID_Bridge_SendTelemetry(uint32_t tick_ms, float setpoint,
                               float actual, float error, float pwm) {
    int len = snprintf(s_tx_buf, sizeof(s_tx_buf),
                       "$TEL,%lu,%.2f,%.2f,%.2f,%.2f\n",
                       (unsigned long)tick_ms, setpoint, actual, error, pwm);
    if (len > 0) {
        HAL_UART_Transmit(s_huart, (uint8_t *)s_tx_buf, len, 10);
    }
}

PID_Params_t PID_Bridge_GetParams(void) {
    return s_params;
}

float PID_Bridge_GetStepTarget(uint8_t *has_new) {
    *has_new = s_has_new_step;
    s_has_new_step = 0;
    return s_step_target;
}

/* ---- 命令解析 ---- */

/* 简单的 strtok 替代: 在 buf 中找第 n 个逗号后的内容 */
static const char *get_field(const char *buf, int n) {
    const char *p = buf;
    for (int i = 0; i < n; i++) {
        p = strchr(p, ',');
        if (!p) return NULL;
        p++;  /* 跳过逗号 */
    }
    return p;
}

static void process_command(const char *line) {
    if (strncmp(line, "$PID,", 5) == 0) {
        /* $PID,<kp>,<ki>,<kd> */
        const char *f1 = get_field(line, 1);
        const char *f2 = get_field(line, 2);
        const char *f3 = get_field(line, 3);
        if (f1 && f2 && f3) {
            s_params.kp = (float)atof(f1);
            s_params.ki = (float)atof(f2);
            s_params.kd = (float)atof(f3);
        }
    } else if (strncmp(line, "$STEP,", 6) == 0) {
        /* $STEP,<target> */
        const char *f1 = get_field(line, 1);
        if (f1) {
            s_step_target = (float)atof(f1);
            s_has_new_step = 1;
        }
    } else if (strncmp(line, "$QUERY", 6) == 0) {
        /* 回复当前参数 */
        int len = snprintf(s_tx_buf, sizeof(s_tx_buf),
                           "$PARAM,%.6f,%.6f,%.6f\n",
                           s_params.kp, s_params.ki, s_params.kd);
        if (len > 0) {
            HAL_UART_Transmit(s_huart, (uint8_t *)s_tx_buf, len, 10);
        }
    }
}
